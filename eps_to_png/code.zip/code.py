from PIL import Image
import os
from tkinter.filedialog import askdirectory
from tkinter.filedialog import askopenfilename
import tkinter as tk
from tkinter import ttk


def epsToPngMapp():
    askDir = askdirectory()
    os.chdir(askDir)
    files = os.listdir()
    pngFile = file[:-4] + '.png'
    counter = 0
    
    for file in files:
        if file.endswith('.eps'):
            epsFile = Image.open(file)
            try:
                rgbEpsFile = epsFile.convert('RGBA')
            except OSError:
                print('OSError')
            try:
                rgbEpsFile.save(pngFile, bitmap_format='png')
                counter+=1
            except:
                print('Error while saving..')
    
    print(f'{counter} .png files created')
    
def epsToPngFil():
    askFile = askopenfilename(initialdir='/', title='Välj fil',  filetypes=(("eps files", "*.eps"), ("all files", "*.*")))
    epsFile = Image.open(askFile)
    pngFile = askFile[:-4] + '.png'
    try:
        rgbEpsFile = epsFile.convert('RGBA')
    except OSError:
        print('OSError')
    try:
        rgbEpsFile.save(pngFile, bitmap_format='png')
    except:
        print('Error while saving..')
    
    print(f'{pngFile} created')
    
    

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.geometry('400x200')
        self.title('EPS to PNG')
        
        self.__create_wid()
        
        
    def __create_wid(self):
        leftFrame = LeftFrame(self)
        leftFrame.grid(row=0, column=0, sticky=tk.NW)
        rightFrame = RightFrame(self)
        rightFrame.grid(row=0, column=1, sticky=tk.NE)



class LeftFrame(ttk.Frame):
    def __init__(self, container):
        super().__init__(container)
        
        self.lbfMapp = tk.LabelFrame(self, text='Välj hel Mapp')
        self.lbfMapp.grid(row=0, column=0, padx=5, pady=5)
        self.__create_wid()
        
        
    def __create_wid(self):
        tk.Label(self.lbfMapp, text='Test').grid(row=0, column=0)
        btnMapp = tk.Button(self.lbfMapp, text='Välj Mapp', command=epsToPngMapp, width=13)
        btnMapp.grid(row=1, column=0, padx=5, pady=5, sticky=tk.EW)



class RightFrame(ttk.Frame):
    def __init__(self, container):
        super().__init__(container)
        
        self.lbfFil = tk.LabelFrame(self, text='Välj enstaka fil')
        self.lbfFil.grid(row=0, column=0, padx=5, pady=5)
        self.__create_wid()
        
        
    def __create_wid(self):
        tk.Label(self.lbfFil, text='Test').grid(row=0, column=0)
        btnFil = tk.Button(self.lbfFil, text='Välj Fil', command=epsToPngFil, width=13)
        btnFil.grid(row=1, column=0, padx=5, pady=5, sticky=tk.EW)


if __name__ == '__main__':
    run = App()
    run.mainloop()